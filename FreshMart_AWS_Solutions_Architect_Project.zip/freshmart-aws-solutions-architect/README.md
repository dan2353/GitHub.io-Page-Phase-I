# FreshMart — AWS Solutions Architect Infrastructure

**A deployable, multi-AZ AWS web infrastructure portfolio project built with Terraform.**

## Business problem
FreshMart needs a resilient grocery storefront that distributes HTTP traffic across two Availability Zones, replaces unhealthy instances, and scales capacity with demand.

## What actually deploys
- One VPC (`10.20.0.0/16`), two public and two isolated private subnets, an Internet Gateway and separate route tables.
- Internet-facing Application Load Balancer (HTTP port 80) with health checks.
- Two EC2 Amazon Linux 2023 instances by default, deployed via Launch Template and Auto Scaling Group across two AZs.
- Security groups: ALB accepts public HTTP; instances accept HTTP only from the ALB security group; no SSH inbound.
- EC2 IAM instance profile with SSM core permissions, IMDSv2 required.
- Encrypted, versioned, private S3 artifacts bucket.
- CloudWatch alarm for unhealthy targets; optional $10/month budget notification (not a spending cap).

## Architecture and tradeoffs
See [architecture](docs/ARCHITECTURE.md), [security](docs/SECURITY.md), and [costs](docs/COSTS.md).

**This is a demonstration, not a production-ready e-commerce application.** It serves a static HTML landing page, not a checkout or database. Instances are in public subnets to avoid NAT Gateway expense; they receive public IPv4 addresses for outbound bootstrap, but security groups block direct inbound HTTP except from the ALB. Private subnets are reserved for later database/data-engineering extensions. HTTP is unencrypted: production requires a domain, ACM certificate and HTTPS listener. There is no deployed RDS, WAF, CloudTrail trail, centralized log archive, or private application tier.

## Prerequisites
1. AWS account with billing access and appropriate permissions; confirm credits and quota.
2. Terraform >=1.5 and AWS CLI installed; credentials configured through `aws configure sso` (recommended) or another secure method.
3. AWS Region `us-west-2` by default. Never commit credentials or state files.

## Deploy
```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars
aws sts get-caller-identity
terraform init
terraform fmt -check
terraform validate
terraform plan -out=tfplan
terraform apply tfplan
terraform output website_url
```

On Windows PowerShell, use `Copy-Item terraform.tfvars.example terraform.tfvars` instead of `cp`. After apply, wait several minutes for instances to initialize and target health checks to pass. Open the printed URL in your browser.

## Test
- VPC console: verify two public and two private subnets in separate AZs.
- EC2 > Target Groups: verify two healthy targets.
- EC2 > Auto Scaling Groups: verify desired=2, min=2, max=3.
- Open ALB URL and `/health` (should return `healthy`).
- Stop **one** demo instance through EC2 console, observe ASG replacement; allow time for recovery. Do not test by deleting the whole ASG.
- S3: verify public access block, versioning and SSE-S3.
- CloudWatch: inspect the unhealthy-target alarm.
- Save redacted screenshots in `screenshots/` (never share account IDs, credentials or private keys).

## Tear down immediately after testing
```bash
cd terraform
terraform destroy
```
Confirm resources are gone in AWS Console, including ALB, EC2, S3 and any retained resources. `terraform destroy` is destructive. Budget notifications do **not** automatically stop charges.

## Next extension: data engineering
Add a private database tier, ingestion to S3, Lambda/Glue transformations, Athena analytics, and dashboards. Revisit NAT/VPC endpoints, encryption, observability and cost before enabling new services.

## Interview talking points
- Explain why ALB and ASG span AZs and how health checks recover service.
- Explain why the public-subnet approach is a **cost-conscious demo compromise**, not the recommended private-instance production architecture.
- Explain subnet routing, least-privilege security groups, IAM roles, IMDSv2, and S3 encryption.
- Discuss the production improvements: HTTPS, private instances, WAF, CloudTrail, log aggregation, RDS Multi-AZ, and deployment pipeline.

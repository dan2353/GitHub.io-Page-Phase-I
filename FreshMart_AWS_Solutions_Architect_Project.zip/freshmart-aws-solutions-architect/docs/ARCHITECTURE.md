# Architecture decisions

```mermaid
flowchart TD
  U[Internet users] --> ALB[Public Application Load Balancer :80]
  subgraph VPC[VPC 10.20.0.0/16]
    subgraph AZ1[Availability Zone A]
      P1[Public subnet 10.20.1.0/24] --> E1[EC2 / Nginx]
      R1[Private subnet 10.20.11.0/24 - reserved]
    end
    subgraph AZ2[Availability Zone B]
      P2[Public subnet 10.20.2.0/24] --> E2[EC2 / Nginx]
      R2[Private subnet 10.20.12.0/24 - reserved]
    end
    ALB --> E1
    ALB --> E2
  end
  ASG[Auto Scaling Group] -.manages.-> E1
  ASG -.manages.-> E2
  CW[CloudWatch alarm] -.monitors.-> ALB
  S3[Private encrypted S3 bucket]
```

## Traffic flow
1. User makes an HTTP request to the ALB DNS hostname.
2. ALB accepts port 80 and forwards to healthy EC2 targets on port 80.
3. Nginx serves a static storefront; `/health` returns 200.
4. The ASG replaces unhealthy EC2 instances and can scale on average CPU.

## Routing
Public subnets have default route `0.0.0.0/0` to Internet Gateway. Private subnets have only VPC-local routes and no NAT. Two Availability Zones provide AZ-level redundancy for the demo application.

## Design constraints
- ALB and public IPv4 addresses cost money.
- EC2 instances run in public subnets and have public IPs, but inbound security-group access is limited to the ALB.
- Private subnets contain no workloads yet.
- No database, customer data, or payment processing is implemented.
- HTTP is used for demo simplicity; no TLS or custom domain.
- Two instances improve resilience, but do not guarantee zero downtime.

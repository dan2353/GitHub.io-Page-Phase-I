# Detailed deployment and validation

## 1. Configure credentials
Use `aws configure sso` or an AWS IAM Identity Center profile with permissions to manage EC2, ELBv2, Auto Scaling, IAM roles, S3, CloudWatch and optionally Budgets. Avoid root-user access keys. Confirm identity using `aws sts get-caller-identity`.

## 2. Prepare Terraform
In `terraform/`, copy `terraform.tfvars.example` to `terraform.tfvars`. Choose a region and review EC2 type and capacity. The defaults create two instances, and the CPU policy can scale to three.

## 3. Validate and deploy
Run `terraform init`, `terraform fmt -check`, `terraform validate`, `terraform plan -out=tfplan`, and `terraform apply tfplan`.

## 4. Verify
Get `terraform output website_url`. Wait for both targets to become healthy. Visit homepage and `/health`. Check EC2 ASG, S3 security settings, VPC routes and CloudWatch alarm.

## 5. Failure test
Terminate one **demo** instance from EC2 console; watch Auto Scaling launch a replacement. Avoid terminating both simultaneously. Note time to recover and capture evidence.

## 6. Cleanup
Run `terraform destroy`. Confirm deletion in the AWS console and Billing. Local state contains infrastructure metadata; never publish it. If destroy fails, fix errors and retry until all project resources are removed.

## Troubleshooting
- ALB 503: no healthy targets; inspect target group health and EC2 user-data logs (`/var/log/cloud-init-output.log`).
- ALB 502: Nginx not listening or target errors; inspect Nginx status and security groups.
- No instances: check ASG activity, EC2 quotas, instance type availability and IAM role/profile.
- `AccessDenied`: verify credentials and required IAM permissions.
- `terraform destroy` errors: inspect AWS resource dependencies, then retry; avoid manual deletion before Terraform has reconciled state.

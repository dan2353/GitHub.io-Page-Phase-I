# SAA-C03 mapping

- Domain 1 Secure architectures: IAM role, IMDSv2, security-group references, private S3 bucket, subnet isolation.
- Domain 2 Resilient architectures: Multi-AZ ALB, target health checks, ASG instance replacement.
- Domain 3 High-performing architectures: ALB distribution, EC2 launch templates, CPU-based scaling.
- Domain 4 Cost-optimized architectures: avoid NAT Gateway for demo, choose small EC2 size, cost monitoring, destroy resources.

**Additional study required:** RDS Multi-AZ vs replicas, Route 53, CloudFront, VPC endpoints, SQS/SNS, EBS/EFS/FSx, S3 storage classes, backup/recovery, and hybrid networking. Building this project alone does not cover the whole exam.

# Cost controls

**Not guaranteed free.** The AWS account, Skill Builder and Cloud Quest may have different entitlements. Verify actual AWS billing and credit terms.

Potential charges: Application Load Balancer hourly and LCU usage; EC2 hours; public IPv4 addresses; EBS root volumes; S3 storage/requests; CloudWatch; data transfer. Free-tier eligibility and credits vary. There is no NAT Gateway or RDS in this project.

Before deployment: review the [AWS Pricing Calculator](https://calculator.aws/) and account Billing > Free Tier/Credits. Optional `alert_email` enables a $10/month AWS Budget with an 80% actual-spend alert; **it does not prevent spending**. Budget notifications may take time and can incur service-specific charges depending on account and usage.

Deploy for a short test window, capture screenshots, run `terraform destroy`, and verify resource removal. Stop and investigate if `terraform apply` fails midway; partially created resources can still cost money.

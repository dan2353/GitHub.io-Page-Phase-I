# Security review

Implemented: instance HTTP ingress only from ALB security group; no SSH ingress; EC2 IAM role instead of embedded credentials; IMDSv2 required; S3 Block Public Access, SSE-S3 encryption and versioning; isolated unused private subnets.

Limitations: ALB accepts plaintext HTTP; instances have public IPs and outbound internet access; no WAF, centralized audit trail, application authentication, or private database. Do not use for real orders, payment information, or personal data.

Production improvements: HTTPS with ACM and Route 53; put application instances in private subnets using appropriate egress via NAT or VPC endpoints; add WAF, CloudTrail, log collection, alarms and a secure data tier; restrict egress and IAM permissions as needed; use remote encrypted Terraform state with locking and CI policies.

Save redacted proof of your actual deployment here: VPC, subnets, target health, Auto Scaling, website, CloudWatch, S3. Do not invent deployment screenshots.

output "website_url" { value = "http://${aws_lb.web.dns_name}" }
output "vpc_id" { value = aws_vpc.main.id }
output "public_subnet_ids" { value = aws_subnet.public[*].id }
output "private_subnet_ids" { value = aws_subnet.private[*].id }
output "artifacts_bucket" { value = aws_s3_bucket.artifacts.bucket }
output "target_group_arn" { value = aws_lb_target_group.web.arn }

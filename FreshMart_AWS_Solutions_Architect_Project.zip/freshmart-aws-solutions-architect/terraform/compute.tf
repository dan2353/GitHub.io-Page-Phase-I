data "aws_ami" "al2023" {
  most_recent = true
  owners = ["amazon"]
  filter { name = "name"; values = ["al2023-ami-2023.*-x86_64"] }
  filter { name = "virtualization-type"; values = ["hvm"] }
}
resource "aws_iam_role" "ec2" {
  name_prefix = "${var.project_name}-ec2-"
  assume_role_policy = jsonencode({ Version = "2012-10-17", Statement = [{ Effect = "Allow", Principal = { Service = "ec2.amazonaws.com" }, Action = "sts:AssumeRole" }] })
}
resource "aws_iam_role_policy_attachment" "ssm" {
  role = aws_iam_role.ec2.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}
resource "aws_iam_instance_profile" "ec2" { name_prefix = "${var.project_name}-profile-"; role = aws_iam_role.ec2.name }
resource "aws_lb" "web" {
  name = "${var.project_name}-alb"
  internal = false
  load_balancer_type = "application"
  security_groups = [aws_security_group.alb.id]
  subnets = aws_subnet.public[*].id
  enable_deletion_protection = false
  drop_invalid_header_fields = true
}
resource "aws_lb_target_group" "web" {
  name = "${var.project_name}-web-tg"
  port = 80
  protocol = "HTTP"
  vpc_id = aws_vpc.main.id
  health_check { path = "/health"; matcher = "200"; interval = 30; healthy_threshold = 2; unhealthy_threshold = 2 }
}
resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.web.arn
  port = 80
  protocol = "HTTP"
  default_action { type = "forward"; target_group_arn = aws_lb_target_group.web.arn }
}
resource "aws_launch_template" "web" {
  name_prefix = "${var.project_name}-web-"
  image_id = data.aws_ami.al2023.id
  instance_type = var.instance_type
  update_default_version = true
  iam_instance_profile { name = aws_iam_instance_profile.ec2.name }
  vpc_security_group_ids = [aws_security_group.web.id]
  metadata_options { http_endpoint = "enabled"; http_tokens = "required" }
  monitoring { enabled = false }
  user_data = base64encode(templatefile("${path.module}/user_data.sh", { project = var.project_name }))
  tag_specifications { resource_type = "instance"; tags = { Name = "${var.project_name}-web" } }
}
resource "aws_autoscaling_group" "web" {
  name = "${var.project_name}-asg"
  vpc_zone_identifier = aws_subnet.public[*].id
  desired_capacity = var.desired_capacity
  min_size = var.min_capacity
  max_size = var.max_capacity
  health_check_type = "ELB"
  health_check_grace_period = 300
  target_group_arns = [aws_lb_target_group.web.arn]
  launch_template { id = aws_launch_template.web.id; version = "$Latest" }
  tag { key = "Name"; value = "${var.project_name}-web"; propagate_at_launch = true }
}
resource "aws_autoscaling_policy" "cpu" {
  name = "${var.project_name}-cpu-target"
  autoscaling_group_name = aws_autoscaling_group.web.name
  policy_type = "TargetTrackingScaling"
  target_tracking_configuration { predefined_metric_specification { predefined_metric_type = "ASGAverageCPUUtilization" }; target_value = 60.0 }
}

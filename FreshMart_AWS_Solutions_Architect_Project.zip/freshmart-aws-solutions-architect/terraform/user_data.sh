#!/bin/bash
set -euxo pipefail
dnf install -y nginx
cat > /usr/share/nginx/html/index.html <<'EOF'
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>FreshMart Cloud</title><style>body{font-family:system-ui,sans-serif;max-width:760px;margin:12vh auto;padding:2rem;background:#f3faf5;color:#173a2b}h1{font-size:3rem}article{background:white;padding:2rem;border-radius:16px;box-shadow:0 5px 20px #0001}</style></head><body><article><h1>FreshMart</h1><p>Fresh groceries. Resilient cloud infrastructure.</p><p>This demo runs on AWS EC2 behind an Application Load Balancer with Auto Scaling across two Availability Zones.</p><p><strong>Status: Healthy</strong></p></article></body></html>
EOF
echo healthy > /usr/share/nginx/html/health
systemctl enable --now nginx

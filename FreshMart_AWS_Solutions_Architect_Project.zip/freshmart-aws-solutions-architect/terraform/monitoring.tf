resource "aws_cloudwatch_metric_alarm" "unhealthy" {
  alarm_name = "${var.project_name}-unhealthy-targets"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods = 2
  metric_name = "UnHealthyHostCount"
  namespace = "AWS/ApplicationELB"
  period = 60
  statistic = "Maximum"
  threshold = 0
  treat_missing_data = "notBreaching"
  dimensions = { LoadBalancer = aws_lb.web.arn_suffix; TargetGroup = aws_lb_target_group.web.arn_suffix }
}
resource "aws_budgets_budget" "monthly" {
  count = var.alert_email == "" ? 0 : 1
  name = "${var.project_name}-monthly-budget"
  budget_type = "COST"
  limit_amount = "10"
  limit_unit = "USD"
  time_unit = "MONTHLY"
  notification {
    comparison_operator = "GREATER_THAN"
    threshold = 80
    threshold_type = "PERCENTAGE"
    notification_type = "ACTUAL"
    subscriber_email_addresses = [var.alert_email]
  }
}

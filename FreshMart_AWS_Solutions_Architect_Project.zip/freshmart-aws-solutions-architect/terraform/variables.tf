variable "aws_region" { type = string; default = "us-west-2" }
variable "environment" { type = string; default = "demo" }
variable "project_name" { type = string; default = "freshmart" }
variable "instance_type" { type = string; default = "t3.micro" }
variable "desired_capacity" { type = number; default = 2 }
variable "max_capacity" { type = number; default = 3 }
variable "min_capacity" { type = number; default = 2 }
variable "alert_email" { type = string; default = ""; description = "Optional email for budget notifications; budget is created only if supplied." }
